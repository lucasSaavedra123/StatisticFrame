import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
from data_analysis import create_dataframe, plot_scatter, plot_line

PARAMS = ['R&D Spend', 'Administration', 'Marketing Spend', 'State', 'Profit']
IND_VAR = ['R&D Spend']
DEP_VAR = ['Profit']

def train_model(dataframe):
    """
    Train a linear regression model with
    its dependent and indepent variables
    from a specific dataframe
    """
    regr = linear_model.LinearRegression()
    ind_variable = dataframe[IND_VAR]
    dep_variable = dataframe[DEP_VAR]
    regr.fit(ind_variable, dep_variable)
    return regr


def betas(regr_model):
    """
    Return beta values given a
    specific model
    """
    beta_2 = regr_model.coef_[0][1]
    beta_1 = regr_model.coef_[0][0]
    beta_0 = regr_model.intercept_[0]
    return beta_2, beta_1, beta_0


def mse(regr_model, dataframe):
    """
    Calculate the Sum of Square Errors
    and then divide them by the amount of instances
    Do not use mean_squared_errors.
    """
    y_model = regr_model.predict(dataframe[IND_VAR])
    y_value = dataframe[DEP_VAR]
    y_values = np.transpose(y_value)
    mse = 0
    for i in range(0, y_values.size):
        mse += np.power(y_values[i] - y_model[i], 2)
    mse /= y_values.size
    return mse


def expected_profit(rd, marketing, regr_model):
    """"
    Predict the profit of a certain startup given the
    variables that you use in your model
    """
    profit = regr_model.predict([[rd, marketing]])
    return profit


def main():
    df = create_dataframe('50_Startups.csv')
    model = train_model(df)
    plot_scatter(df[IND_VAR], df[DEP_VAR], "R&D", "PROFIT")
    plot_line()
    plt.show()

    """
    print(df.describe())
    print("Betas: ", betas(model))
    print("MSE: ", mse(model, df)[0])
    print("Ingreso calculado: ", expected_profit(40000, 129300, model))
    """

if __name__ == '__main__':
    main()
