from data_analysis import *
from data_preparation import *
import statsmodels.api as sm
import operator
import numpy as np


def forward_stepwise_selection(dataframe, target):
    """
    Given a dataframe and a target variable
    implement the forward stepwise selection algorithm and return
    and array with all the r2 values
    """
    var_explicativas = dataframe.drop(target, axis=1)
    var_explicativas = sm.add_constant(var_explicativas)
    var_objetivo = dataframe[[target]]
    # set initial conditions
    variables = ['const']
    iterate_columns = var_explicativas.columns.drop('const')
    vars_size = iterate_columns.size
    r2_adj = []
    var_model = {}
    # iterate k times, being k the amount of variables
    for k in range(0, vars_size):
        # add r2 values for each variable in use in the model
        r2 = {}
        # iterate over all the available variables
        for var in iterate_columns:
            # set which variables we will use
            var_explicativa = var_explicativas[variables + [var]]
            model = sm.OLS(var_objetivo, var_explicativa)
            regr = model.fit()
            # store each r2 value
            r2[var] = regr.rsquared_adj
        # pick the one with the higher r2
        var_max_r2 = max(r2.items(), key=operator.itemgetter(1))[0]
        # store the variables that describe this model
        var_model[k] = var_max_r2
        # add the values of r2
        r2_adj.append(r2[var_max_r2])
        # delete the variable that is no longer in consideration
        iterate_columns = iterate_columns.drop(var_max_r2)
        # we add the variable as it is incorporated in the model
        variables.append(var_max_r2)
    return r2_adj, var_model


def backward_stepwise_selection(dataframe, target):
    """
    Given a dataframe and a target variable
    implement the forward stepwise selection algorithm and return
    and array with all the r2 values
    """
    var_explicativas = dataframe.drop(target, axis=1)
    var_explicativas = sm.add_constant(var_explicativas)
    var_objetivo = dataframe[[target]]
    # set initial conditions
    variables = var_explicativas.columns
    iterate_columns = variables.drop('const')
    vars_size = iterate_columns.size
    r2_adj = []
    var_model = {}
    # iterate k times, being k the amount of variables
    for k in range(0, vars_size):
        # add r2 values for each variable in use in the model
        r2 = {}
        # index to insert temporarly removed variables
        i = 1
        #  iterate over all the available variables
        for var in iterate_columns:
            # delete the variable to be deleted
            variables = variables.drop(var, 1)
            # set which variables we will use
            var_explicativa = var_explicativas[variables]
            # we insert again the temporary removed variable
            variables = variables.insert(i, var)
            # train the model
            model = sm.OLS(var_objetivo, var_explicativa)
            regr = model.fit()
            # store the variables that describe this model
            r2[var] = regr.rsquared_adj
            # update index
            i += 1
        # pick the one with the higher r2
        var_max_r2 = max(r2.items(), key=operator.itemgetter(1))[0]
        # add the values of r2
        r2_adj.append(r2[var_max_r2])
        # store the variables that describe this model
        var_model[k] = var_max_r2
        # delete tha variable that will not be in consideration for the next iteration
        iterate_columns = iterate_columns.drop(var_max_r2)
        # delete tha variable that will not be in consideration for the model
        variables = variables.drop(var_max_r2, 1)
    return r2_adj, var_model


def backward_stepwise_selection_pvalues(dataframe, target):
    """
    Given a dataframe and a target variable
    implement the forward stepwise selection algorithm with p values
    and return and array with all the r2 values
    """
    var_explicativas = dataframe.drop(target, axis=1)
    vars_size = var_explicativas.columns.size
    var_explicativas = sm.add_constant(var_explicativas)
    var_objetivo = dataframe[[target]]
    # set initial conditions
    variables = var_explicativas.columns
    r2_adj = []
    vars_out = []
    for k in range(0, vars_size):
        var_explicativa = var_explicativas[variables]
        # train the model
        model = sm.OLS(var_objetivo, var_explicativa)
        regr = model.fit()
        # store the r2 value
        r2_adj.append(regr.rsquared_adj)
        # obtain  all the p-values but the one from const
        p_values = regr.pvalues.drop('const')
        pvalue_index = p_values.argmax()
        pvalue_var = p_values.keys()[pvalue_index]
        # delete the variable with the highest p value
        variables = variables.drop(pvalue_var)
        # store the variable that is no longer in consideration
        vars_out.append(pvalue_var)
    return r2_adj


def r2_variation(vars_size, r2_adj, title, x_label, y_label):
    """
    Plot the scatter and the curve that shows how R2 value vary over
    every iteration. A title and labels for the graph must be included.
    Also, highlight the point where there is a maximum R2 value. Add information
    about that point. The amount of independent variables is given.
    """
    # set x values
    x = np.arange(vars_size)
    # get the (x, y) values for the highest r2 value
    r2_max_x = r2_adj.index(max(r2_adj))
    r2_max_y = max(r2_adj)
    # titles and labels of our chart
    plt.title(title, loc='left')
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    # plot the curve
    plt.plot(x, r2_adj)
    # plot all the r2 values as points
    plt.scatter(x, r2_adj)
    # plot the highest r2 value and some information about it
    plt.scatter(r2_max_x, r2_max_y, marker='*', s=100, color='red')
    plt.text(r2_max_x * (1 + 0.01), r2_max_y * 0.97, round(r2_max_y, 3), fontsize=12)
    plt.text(r2_max_x * (1 + 0.01), r2_max_y * 0.95, 'k = ' + str(r2_max_x), fontsize=12)
    plt.show()


def create_model(r2_adj, var_model, dataframe, target, mode):
    """
    Create a linear regression model with the variable/s that has
    the highest r2 value given by a selection stepwise algorithm
    """
    var_explicativas = dataframe.drop(target, axis=1)
    var_explicativas = sm.add_constant(var_explicativas)
    var_objetivo = dataframe[[target]]
    r2_max_x = r2_adj.index(max(r2_adj))
    if mode == 'f':
        variables = []
    if mode == 'b':
        variables = var_explicativas.columns
    i = 0
    while i <= r2_max_x:
        if mode == 'f':
            variables.append(var_model[i])
        if mode == 'b':
            variables = variables.drop(var_model[i], 1)
        i += 1
    var_explicativa = var_explicativas[variables]
    var_explicativa = sm.add_constant(var_explicativa)
    model = sm.OLS(var_objetivo, var_explicativa)
    regr = model.fit()
    return regr


def main():
    df = create_dataframe('insurance-ready.csv')

    r2_adj, var_model = forward_stepwise_selection(df, 'charges')
    r2_variation(df.columns.size - 1, r2_adj, 'Forward Stepwise Selection', 'k', 'R2 Values')
    regr = create_model(r2_adj, var_model, df, 'charges', 'f')
    cost = regr.predict([1, 0, 25, 26, 0, 1, 0])
    print(regr.summary())
    print("Estimated cost of insurance: US$", round(cost[0], 2))


    r2_adj, var_model = backward_stepwise_selection(df, 'charges')
    r2_variation(df.columns.size - 1, r2_adj, 'Backward Stepwise Selection', 'k', 'R2 Values')
    regr = create_model(r2_adj, var_model, df, 'charges', 'b')
    cost = regr.predict([1, 25, 26, 0, 0, 0, 1])
    print(regr.summary())
    print("Estimated cost of insurance: US$", round(cost[0], 2))

    r2_adj = backward_stepwise_selection_pvalues(df, 'charges')
    r2_variation(df.columns.size - 1, r2_adj, 'Backward Stepwise Selection with pvalues', 'k', 'R2 Values')


if __name__ == '__main__':
    main()
