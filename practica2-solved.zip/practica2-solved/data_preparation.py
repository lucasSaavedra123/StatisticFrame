from data_analysis import *


def set_dummy_variable(dataframe, column, label):
    """
    Given a dataframe create dummy variables for a specific column
    Replace the old column and add the new ones
    """
    dummy = pd.get_dummies(column, prefix=label)
    index = dataframe.columns.get_loc(label)
    dataframe = dataframe.drop(label, axis=1)
    i = dummy.columns[0]
    dataframe.insert(index, dummy[i].name, dummy[i], True)
    if dummy.columns.size > 2:
        cols = dummy.columns[1:]
        for i in cols:
            dataframe.insert(index, dummy[i].name, dummy[i], True)
            index += 1
    return dataframe


def add_dummies(dataframe, columns):
    """
    Add dummy variables for every column given
    return the dataframe
    """
    for col in columns:
        dataframe = set_dummy_variable(dataframe, dataframe[[col]], col)
    return dataframe


def main():
    # Program steps
    df = create_dataframe('insurance.csv')
    df = add_dummies(df, ['sex', 'smoker', 'region'])
    df.to_csv('insurance-ready.csv', index=False)
    # Set console visualization
    pd.set_option('display.width', 200)
    pd.set_option('display.max_columns', df.columns.size)
    # visualize data
    # plot_scatter(df[['bmi']], df[['charges']], 'bmi', 'charges')
    #plt.show()
    print(df)


if __name__ == '__main__':
    main()
