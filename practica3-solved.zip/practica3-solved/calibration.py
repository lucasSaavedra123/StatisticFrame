from data_analysis import *
import statsmodels.api as sm
from sklearn.preprocessing import PolynomialFeatures
import matplotlib.pyplot as plt
import numpy as np

"""
Reference:	Chwirut, D., NIST (1979). 
Ultrasonic Reference Block Study.
"""


def train_model(dep_variables, target, mode, degree=1):
    """
    Return a non linear regression model either polynomial
    or logarithmic according to mode parameter.
    """
    if mode == 'p':
        polynomial_features = PolynomialFeatures(degree=degree)
        x = polynomial_features.fit_transform(dep_variables)
    if mode == 'l':
        x = np.log10(dep_variables)
        target = np.log10(target)
        x = sm.add_constant(x)
    model = sm.OLS(target, x)
    regr = model.fit()
    return regr


def plot_solution(model, dataframe, mode):
    """
    Generate x values and with your model predict y
    values. Plot them as a curve and with a given dataframe
    plot every (x, y) value
    """
    pass


def is_calibrated(x, y, model, mode):
    """
    From the values obtained from the calibration
    determine if the ultrasonic device is ready for use or not.
    """
    if mode == 'p':
        y_pred = model.predict(x)
    if mode == 'l':
        # Find betas
        beta_0 = model.params[0]
        beta_1 = model.params[1]
        # Transform values
        a = np.power(10, beta_0)
        y_pred = a * np.power(x, beta_1)

    if y_pred * 0.95 <= y <= y_pred * 1.05:
        print("Calibrated")
    else:
        print("No Calibrated")


def main():
    # this should work
    df = create_dataframe('Chwirut1.csv')
    # polinomial of degree 2
    print(train_model(df[['metal_distance']], df[['ultrasonic_response']], 'p', 2).summary())
    # polinomial of degree 3
    print(train_model(df[['metal_distance']], df[['ultrasonic_response']], 'p', 3).summary())
    # logarithmic
    print(train_model(df[['metal_distance']], df[['ultrasonic_response']], 'p').summary())
    # the program
    model = train_model(df[['metal_distance']], df[['ultrasonic_response']], 'l')
    print('press 0 to stop, 1 to continue')
    i = 1
    while i:
        print('Metal distance')
        x = float(input())
        print('Ultrasonic Value')
        y = float(input())
        is_calibrated(x, y, model, 'l')
        print('Continue?')
        i = int(input())


if __name__ == '__main__':
    main()